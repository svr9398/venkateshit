package com.example.demo.repo;

import java.util.List;

import org.hibernate.type.descriptor.converter.spi.JpaAttributeConverter;

import com.example.demo.bean.Lease;

public interface LeaseRepo extends JpaAttributeConverter<Lease, Long> {
	
	 List<Lease> findByCustomerId(Long customerId);

}
