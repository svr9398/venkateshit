package com.example.demo.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.example.demo.bean.Car;
import com.example.demo.bean.User;
import com.example.demo.repo.CarRepo;
import com.example.demo.repo.UserRepository;

@Service

public class CarService {

	private CarRepo carRepo;

	private UserRepository userRepository;

	public Car registerCar(Long ownerId, Car car) {

		User owner = userRepository.findById(ownerId).orElseThrow();

		car.setStatus("IDLE");
		car.setOwner(owner);
		return carRepo.save(car);

	}

	public List<Car> getCarsByOwner(Long ownerId) {

		return carRepo.findAll().stream().filter(car -> car.getOwner().getId().equals(ownerId))
				.collect(Collectors.toList());
	}

	public List<Car> getAllCars() {
		return carRepo.findAll();

	}

}
